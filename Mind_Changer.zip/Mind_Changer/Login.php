<?php
    session_start();
        $var = $_SESSION['status'];
   if( $var == 1)
    {
        header("location: userHomepage.html");
    }

?>
<html>
<head>
<title>Login Form Design</title>
    <link rel="stylesheet" type="text/css" href="loginStyle.css">
        <style type="text/css">
    .loginbox{
    width: 320px;
    height: 520px;
    background: #000;
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
    }
    </style>
<body>
    <div class="loginbox">
    <img src="C:\Users\tejas\Desktop\Algo 6.0\Image\avatar.png" class="avatar">
        <h1>Login Here</h1>
        <form class="float_form" action="login_handler.php" method="POST">
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Username" required>
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password" required>
                Customer <input type='radio' name='user_type' value='Customer' checked/> Administrator <input type='radio' name='user_type' value='Administrator'/>
                <br>
            <?php
                    if(isset($_GET['msg']) && $_GET['msg']=='failed')
                    {
                        echo "<br>
                        <strong style='color:red'>Invalid Username/Password</strong>
                        <br><br>";
                    }
                ?>
            <input type="submit" name="Login" value="Login">
            <a href="newuser.php">Don't have an account?</a>
        </form>
        
    </div>

</body>
</head>
</html>