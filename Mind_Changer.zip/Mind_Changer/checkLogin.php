
<?php
    session_start();
    $var = $_SESSION['status'];
   if( $var == 1)
   	{
   		header("location: programHomepage.php");
   	}
   	else {
   		header("location: Login.php");
   	}
?>