<html>
	<head>
		<title>Logout Handler</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION["status"] = 0;
			// session_destroy();
			header("location: start.html");
		?>
	</body>
</html>