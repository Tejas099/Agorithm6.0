Simple HTML5 meditation timer
