<html>
	<head>
		<title>Add New User</title>
	</head>
	<body>
		// <?php
			if(isset($_POST['Submit']))
			{
				$data_missing=array();
				if(empty($_POST['name']))
				{
					$data_missing[]='Name';
				}
				else
				{
					$name=trim($_POST['name']);
				}
				if(empty($_POST['age']))
				{
					$data_missing[]='age';
				}
				else
				{
					$age=$_POST['age'];
				}
				if(empty($_POST['gender']))
				{
					$data_missing[]='Gender';
				}
				else
				{
					$gender=trim($_POST['gender']);
				}

				if(empty($_POST['username']))
				{
					$data_missing[]='Username';
				}
				else
				{
					$username=$_POST['username'];
				}
				if(empty($_POST['password']))
				{
					$data_missing[]='password';
				}
				else
				{
					$password=trim($_POST['password']);
				}

				if(empty($data_missing))
				{
					require_once('mysqliconnect.php');
					$query="INSERT INTO customer (name,age,gender,username,pwd) VALUES (?,?,?,?,?)";
					$stmt=mysqli_prepare($dbc,$query);
					mysqli_stmt_bind_param($stmt,"sssss",$name,$age,$gender,$username,$password);
					mysqli_stmt_execute($stmt);
					$affected_rows=mysqli_stmt_affected_rows($stmt);
					//echo $affected_rows."<br>";
					// mysqli_stmt_bind_result($stmt,$cnt);
					// mysqli_stmt_fetch($stmt);
					// echo $cnt;
					mysqli_stmt_close($stmt);
					mysqli_close($dbc);
					/*
					$response=@mysqli_query($dbc,$query);
					*/
					if($affected_rows==1)
					{
						header("location: Login.php");
					}
					else
					{
						echo "Something Went Wrong";
						echo mysqli_error();
					}
				}
				else
				{
					echo "The following data fields were empty! <br>";
					foreach($data_missing as $missing)
					{
						echo $missing ."<br>";
					}
				}
			}
			else
			{
				echo "Submit request not received";
		 }
// Include('mysqliconnect.php')
// if(isset($_REQUEST['submit'])!='')
// {
// if($_REQUEST['name']=='' || $_REQUEST['age']=='' || $_REQUEST['gender']==''|| $_REQUEST['username']=='' ||$_REQUEST['password']==''  )
// {
// echo "please fill the empty field.";
// }
// else
// {
// $sql="insert into customer(name,age,gender,username,pwd) values('".$_REQUEST['name']."', '".$_REQUEST['age']."', '".$_REQUEST['gender']."', '".$_REQUEST['username']."', '".$_REQUEST['password']."')";
// $res=mysql_query($sql);
// if($res)
// {
// echo "Record successfully inserted";
// }
// else
// {
// echo "There is some problem in inserting record";
// }

// }
// }
?>
	</body>
</html>