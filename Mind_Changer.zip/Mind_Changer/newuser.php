<html>
<head>
<title>Login Form Design</title>
    <link rel="stylesheet" type="text/css" href="loginStyle.css">
    <style type="text/css">
    .loginbox{
    width: 320px;
    height: 620px;
    background: #000;
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
    }
    </style>
<body>
    <div class="loginbox">
    <img src="Image\avatar.png" class="avatar">
        <h1>Register Here</h1>
        <form class="center_form" action="new_user_handler.php" method="POST" id="new_user_from">
            <p>Name</p>
            <input type="text" name="name" placeholder="Name" required>
            <p>Age</p>
            <input type="number" name="age" placeholder="Age" required>
            <p>Gender</p>
            <input type="text" name="gender" placeholder="Gender" required>
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Username" required>
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password" required>
            <input type="submit" name="Submit" value="Submit">
            <a href="login.php">Back</a>
        </form>
        
    </div>

</body>
</head>
</html>