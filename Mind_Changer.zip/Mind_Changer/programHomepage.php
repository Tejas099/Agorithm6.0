<?php
    session_start();
        $var = $_SESSION['status'];
   if( $var == 0)
    {
        header("location: Login.php");
    }

?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Program Section</title>
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="CSS/reset.css">
    <!-- for font -->
    <link href='http://fonts.googleapis.com/css?family=Crete+Round' rel='stylesheet' type='text/css'>
    <!-- for style -->
    <link rel="stylesheet" type="text/css" href="CSS/programHomepage.css">

    <style type="text/css">
        
.sticky {
  position: fixed;
  top: 0;
  width: 100%;
  height: 120px;
  background-color:#ffffff;
}


    </style>
</head>
<body>
        <!-- header -->
   <header id="myHeader">
    <div class="wrapper">
        <h1>Program Section<span class="color">.</span></h1>
        <nav>
            <ul>
                <li><a href="start.html">Home</a></li>
                <li><a href="Login.php">LOG IN</a></li>
                <!-- <li><a href="#secondary-content">REGISTRATION</a></li> -->
                <li><a href="#footerinfo">Contact Us</a></li>
            </ul>


        </nav>

    </div>
</header>
<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>

<div class="chapter_summary">
    <ul>
        <li><a href="#primary-content">Introduction</a></li>
        <li><a href="#primary-content2">What is Stress ?</a></li>
        <li><a href="#primary-content3">What happens in Stress ?</a></li>
        <li><a href="stress_handler/stress.html">Stress Tracker</a></li>
        <li><a href="meditation-gh-pages/Meditation.html">Activity</a></li>
    </ul>
</div>

<div id="primary-content">
    <div class="wrapper">
        <article>
            <h3>Introduction.</h3>
            <p>This program will provide you with information and valid techniques to better understand your anxiety.
As you move forward in the program ,you will be equipped with techniques and exerises,which will deal with anxiety
you may be facing regularly .Once you complete an activity for the first time,it will then become avialable in the
'Activity' section and can be used at any time.The more you practice the better you become at using these techniques
to help you tackle your anixety.For any other guidance assistance or advice,your coach is always available.
Rest assured, you can communicate with complete freedom without having to worry about anything as you are anonymous 
by default on our program</p>
            <a href="#"><img src="Images/projectpage_img_introduction.png" alt="video placeholder" 
                width="100px" /></a>

        </article>
<audio controls>
  <source src="Audio/outputintro.mp3" type="audio/mpeg">

Your browser does not support the audio element.
</audio>
    </div>
</div>


<div id="primary-content2">
    <div class="wrapper">
        <article>
            <h3>What is Stress?</h3>
            <p>Psychologically speaking,stress is a
feeling of strain or pressure, and a type of psychological pain. Excessive amounts of stress can bodily harm, and 
can increase the risk of strokes, heart attacks,ulcers and mental illnesses like depression.
But what causes stress to one person may not be stressful to another.You may feel very stressed before a speech 
you need to give to a room full of people,but a stand-up comedian may be much more at ease in the same situation!
So, we can conclude that what you preceive as threatening may not seem scary to someone else.
Think of a time when you've felt stressed.Have you ever felt overhelmed with everything that's happening around you
and couldn't figure out what to do?
Don't worry ,you aren't alone!
People experience stress ,when they belive that they do not have the adequate resources to deal with the obstacles
that they're faced with.These obstacles could be a bumch of things happening all at once!</p>
            <a href="#"><img src="Images/projectpage_img_stress.png" alt="video placeholder" 
                width="100px" /></a>

        </article>
        <audio controls>
  <source src="Audio/outputStress.mp3" type="audio/mpeg">

Your browser does not support the audio element.
</audio>
    </div>
</div>


<div id="primary-content3">
    <div class="wrapper">
        <article>
            <h3>What Happens in our bodies when we are stressed?</h3>
            <p>
Psychologically speaking,stress is a
feeling of strain or pressure, and a type of psychological pain. Excessive amounts of stress can bodily harm, and 
can increase the risk of strokes, heart attacks,ulcers and mental illnesses like depression.
But what causes stress to one person may not be stressful to another.You may feel very stressed before a speech 
you need to give to a room full of people,but a stand-up comedian may be much more at ease in the same situation!
So, we can conclude that what you preceive as threatening may not seem scary to someone else.
Think of a time when you've felt stressed.Have you ever felt overhelmed with everything that's happening around you
and couldn't figure out what to do?
Don't worry ,you aren't alone!
People experience stress ,when they belive that they do not have the adequate resources to deal with the obstacles
that they're faced with.These obstacles could be a bumch of things happening all at once!</p>
            <a href="#"><img src="Images/projectpage_img_body.png" alt="video placeholder" 
                width="100px" /></a>
        </article>
                <audio controls>
  <source src="Audio/outputStresscause.mp3" type="audio/mpeg">

Your browser does not support the audio element.
</audio>
    </div>
</div>




















<footer id="footerinfo">
    <div class="wrapper">
        <div id="footer-info">
            <p>Emotional & Mental</p>
            <p>Wellness at your fingertips.</p>
        </div>
        <div id="footer-links">
            <ul>
                <li><h5>Company</h5></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Meet The Team</a></li>
                <li><a href="#">What We Do</a></li>
                <li><a href="#">Careers</a></li>
            </ul>

        </div>
        <div class="clear"></div>
    </div>
</footer>

</body>
</html>